    1  ls
    2  key-geb ssh
    3  key-gen ssh
    4  key ssh
    5  ssh key-gen
    6  ssh keygen
    7  ssh-keygen
    8  cat ..ssh/id_ed25519.pub
    9  cat ssh/id_ed25519.pub
   10  cat .ssh/id_ed25519.pub
   11  cat .ssh/id_rsa.pub
   12  cat .ssh/id_rsa.pub
   13  ls
   14  cat .ssh/id_rsa.pub
   15  cat /home/pagechiv/.ssh/id_ed25519.pub
   16  cd
   17  ls
   18  cd Desktop/
   19  ls
   20  git clone [200~ssh://git@repos-ssh.21-school.ru:2289/students_repo/pagechiv/T01D01.ID_239606-1.git~
   21  git clone ssh://git@repos-ssh.21-school.ru:2289/students_repo/pagechiv/T01D01.ID_239606-1.git
   22  git clone ssh://git@repos-ssh.21-school.ru:2289/students_repo/pagechiv/T01D01.ID_239606-1.git
   23  ls
   24  cd T01D01.ID_239606-1/
   25  cd src
   26  ls
   27  bash ai_initial_module.sh 
   28  bash ai_initial_module.sh 
   29  chmod +x ai_module_2.sh 
   30  bash ai_initial_module.sh 
   31  git init
   32  ls
   33  cd
   34  git branch
   35  cd Desktop/
   36  cd T01D01.ID_239606-1/
   37  git branch
   38  git checkout -b develop
   39  git branch
   40  git init
   41  git add .
   42  gti commit "changed to new branch"
   43  gti commit -m "changed to new branch"
   44  git commit -m "changed to new branch"
   45  git status
   46  git branch
   47  git push 
   48  git push --set-upstream origin develop
   49  bash ai_initial_module.sh
   50  cd src
   51  bash ai_initial_module.sh 
   52  git branch
   53  git branch
   54  cd ..
   55  git branch
   56  cd src
   57  ls
   58  bash ai_initial_module.sh 
   59  git init
   60  git add ai_initial_module.sh 
   61  git commit -m "done"
   62  git push 
   63  git push origin develop
   64  git push 
   65  git push origin develop
   66  git push develop
   67  git status
   68  git checkout develop
   69  git switch develop
   70  git branch
   71  git clear
   72  cd
   73  clear
   74  cd
   75  cd Desktop/
   76  ls
   77  cd T01D01.ID_239606-1/
   78  ls
   79  git status
   80  git branch
   81  cd src
   82  git branch
   83  cd ..
   84  git branch
   85  cd src
   86  git branch
   87  git checkout -b develop
   88  git status
   89  ls
   90  git add .
   91  git push origin develop
   92  git push 
   93  git push origin develop
   94  git push origin develop
   95  bash ai_initial_module.sh 
   96  git add ai_initial_module.sh 
   97  git commit -m "done"
   98  git add ai_initial_module.sh 
   99  git commit -m "done"
  100  git push 
  101  git push origin develop
  102  git push origin/develop
  103  git push --set-upstream origin develop
  104  cd ..
  105  git push origin develop
  106  bash ai_initial_module.sh 
  107  cd src
  108  bash ai_initial_module.sh 
  109  bash ai_door_management_module.sh 
  110  nano ai_door_management_module.sh 
  111  nano ai_door_management_module.sh 
  112  ls
  113  bash ai_door_management_module.sh 
  114  history > command.txt
  115  ls
  116  cat command.txt 
  117  rm command.txt 
  118  ls
  119  mv door_management_fi door_management_files
  120  ls
  121  bash ai_door_management_module.sh 
  122  cd
  123  cd Desktop/
  124  cd T01D01.ID_239606-1/
  125  ls
  126  cd src
  127  ls
  128  cd door_management_files/
  129  ls
  130  mkdir door_configuration
  131  mv *.conf door_configuration/
  132  ls
  133  cd door_configuration/
  134  ls
  135  cd ..
  136  mkdir door_map
  137  mkdir door_logs
  138  mv *.log door_logs/
  139  ls
  140  mv door_map_1.1 door_map
  141  ls
  142  cd
  143  cd Desktop/T01D01.ID_239606-1/src/
  144  bash ai_door_management_module.sh 
  145  chmod +x ai_door_control.sh 
  146  bash ai_door_management_module.sh 
  147  g
  148  ps aux | grep ai_door_control.sh
  149  kill -9 100590
  150  history > quest3.sh
  151  nano quest3.sh
  152  nano quest3.sh
  153  history > quest4.sh
